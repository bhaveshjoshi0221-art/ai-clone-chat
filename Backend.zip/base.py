from sqlalchemy.orm import DeclarativeBase


class Base(DeclarativeBase):
    pass


# Import all models here so Alembic / create_all can discover them
from app.models.user import User          # noqa: F401, E402
from app.models.message import Message, Conversation, ConversationMember  # noqa: F401, E402
from app.models.ai_clone import AIClone, TrainingSession  # noqa: F401, E402
