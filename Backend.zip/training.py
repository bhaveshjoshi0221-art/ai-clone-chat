from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.deps import get_current_user, get_db
from app.models.user import User
from app.models.ai_clone import AIClone, TrainingSession
from app.services.training_service import rebuild_personality_prompt

router = APIRouter()


# ── Schemas ────────────────────────────────────────────────────────────────

class TrainingTurnRequest(BaseModel):
    prompt: str
    response: str


class TrainingTurnOut(BaseModel):
    id: UUID
    clone_id: UUID
    prompt: str
    response: str
    created_at: str

    model_config = {"from_attributes": True}


class TrainingStatsOut(BaseModel):
    clone_id: UUID
    total_turns: int
    personality_prompt: str


# ── Routes ─────────────────────────────────────────────────────────────────

@router.post("/turns", response_model=TrainingTurnOut, status_code=status.HTTP_201_CREATED)
async def add_training_turn(
    body: TrainingTurnRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> TrainingSession:
    clone = await _get_clone(db, current_user.id)

    if not body.prompt.strip() or not body.response.strip():
        raise HTTPException(status_code=400, detail="Prompt and response cannot be empty")

    session = TrainingSession(
        user_id=current_user.id,
        clone_id=clone.id,
        prompt=body.prompt.strip(),
        response=body.response.strip(),
    )
    db.add(session)

    clone.training_turns += 1

    # Rebuild system prompt every 10 new turns
    if clone.training_turns % 10 == 0:
        updated_prompt = await rebuild_personality_prompt(clone, db)
        clone.personality_prompt = updated_prompt

    await db.commit()
    await db.refresh(session)
    return session


@router.get("/turns", response_model=list[TrainingTurnOut])
async def get_training_turns(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> list[TrainingSession]:
    clone = await _get_clone(db, current_user.id)
    result = await db.execute(
        select(TrainingSession)
        .where(TrainingSession.clone_id == clone.id)
        .order_by(TrainingSession.created_at.desc())
        .limit(100)
    )
    return result.scalars().all()


@router.get("/stats", response_model=TrainingStatsOut)
async def get_training_stats(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> dict:
    clone = await _get_clone(db, current_user.id)
    return {
        "clone_id": clone.id,
        "total_turns": clone.training_turns,
        "personality_prompt": clone.personality_prompt,
    }


@router.post("/rebuild-prompt", response_model=TrainingStatsOut)
async def force_rebuild_prompt(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> dict:
    clone = await _get_clone(db, current_user.id)
    updated_prompt = await rebuild_personality_prompt(clone, db)
    clone.personality_prompt = updated_prompt
    await db.commit()
    await db.refresh(clone)
    return {
        "clone_id": clone.id,
        "total_turns": clone.training_turns,
        "personality_prompt": clone.personality_prompt,
    }


@router.delete("/turns/{turn_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_training_turn(
    turn_id: UUID,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> None:
    result = await db.execute(
        select(TrainingSession).where(
            TrainingSession.id == turn_id,
            TrainingSession.user_id == current_user.id,
        )
    )
    session = result.scalar_one_or_none()
    if not session:
        raise HTTPException(status_code=404, detail="Training turn not found")
    await db.delete(session)
    await db.commit()


# ── Helper ─────────────────────────────────────────────────────────────────

async def _get_clone(db: AsyncSession, user_id: UUID) -> AIClone:
    result = await db.execute(select(AIClone).where(AIClone.user_id == user_id))
    clone: AIClone | None = result.scalar_one_or_none()
    if not clone:
        raise HTTPException(status_code=404, detail="Clone not found")
    return clone
