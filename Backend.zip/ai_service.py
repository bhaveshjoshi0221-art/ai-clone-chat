"""
AI Service — HuggingFace Inference API
Generates replies in the style of a user's AI clone.
"""

import asyncio
import logging
from typing import AsyncIterator

import httpx
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.models.ai_clone import AIClone, TrainingSession

log = logging.getLogger(__name__)

_HF_HEADERS = {
    "Authorization": f"Bearer {settings.AI_API_KEY}",
    "Content-Type": "application/json",
}

# Number of recent training examples included in context
_FEW_SHOT_EXAMPLES = 6


# ── Few-shot context builder ───────────────────────────────────────────────

async def _build_few_shot_context(clone: AIClone, db: AsyncSession) -> str:
    result = await db.execute(
        select(TrainingSession)
        .where(TrainingSession.clone_id == clone.id)
        .order_by(TrainingSession.created_at.desc())
        .limit(_FEW_SHOT_EXAMPLES)
    )
    sessions = list(reversed(result.scalars().all()))

    if not sessions:
        return ""

    lines = ["Here are examples of how this person communicates:\n"]
    for s in sessions:
        lines.append(f"User said: {s.prompt}")
        lines.append(f"They replied: {s.response}\n")
    return "\n".join(lines)


# ── Prompt assembly ────────────────────────────────────────────────────────

async def _assemble_prompt(
    clone: AIClone,
    trigger_message: str,
    db: AsyncSession,
) -> str:
    few_shot = await _build_few_shot_context(clone, db)

    system = clone.personality_prompt
    if few_shot:
        system = f"{system}\n\n{few_shot}"

    # Mistral instruct format
    prompt = (
        f"<s>[INST] <<SYS>>\n{system}\n<</SYS>>\n\n"
        f"Someone sent you this message: {trigger_message}\n\n"
        f"Reply naturally as this person would. Be concise. [/INST]"
    )
    return prompt


# ── HuggingFace API call ───────────────────────────────────────────────────

async def _call_hf_api(prompt: str) -> str:
    url = f"{settings.AI_API_URL}/{settings.AI_MODEL_NAME}"
    payload = {
        "inputs": prompt,
        "parameters": {
            "max_new_tokens": settings.AI_MAX_NEW_TOKENS,
            "temperature": settings.AI_TEMPERATURE,
            "do_sample": True,
            "return_full_text": False,
        },
    }

    async with httpx.AsyncClient(timeout=settings.AI_TIMEOUT_SECONDS) as client:
        response = await client.post(url, headers=_HF_HEADERS, json=payload)

    if response.status_code == 503:
        # Model loading — wait and retry once
        log.warning("HF model loading (503), retrying in 20s…")
        await asyncio.sleep(20)
        async with httpx.AsyncClient(timeout=settings.AI_TIMEOUT_SECONDS + 20) as client:
            response = await client.post(url, headers=_HF_HEADERS, json=payload)

    if response.status_code != 200:
        log.error("HF API error %s: %s", response.status_code, response.text)
        raise RuntimeError(f"HuggingFace API returned {response.status_code}")

    data = response.json()

    # HF returns list of generated texts
    if isinstance(data, list) and data:
        text: str = data[0].get("generated_text", "")
    elif isinstance(data, dict):
        text = data.get("generated_text", "")
    else:
        raise RuntimeError("Unexpected HF API response shape")

    return text.strip()


# ── Public interface ───────────────────────────────────────────────────────

async def generate_clone_reply(
    clone: AIClone,
    trigger_message: str,
    db: AsyncSession,
) -> str:
    """
    Generate a reply from an AI clone given a trigger message.
    Falls back to a safe default if the API fails.
    """
    try:
        prompt = await _assemble_prompt(clone, trigger_message, db)
        reply = await _call_hf_api(prompt)
        if not reply:
            return "I'll get back to you soon!"
        return reply
    except Exception as exc:
        log.exception("generate_clone_reply failed for clone=%s: %s", clone.id, exc)
        return "I'm busy right now, I'll reply later!"


async def stream_clone_reply(
    clone: AIClone,
    trigger_message: str,
    db: AsyncSession,
) -> AsyncIterator[str]:
    """
    Streaming version — yields token chunks.
    Uses HF text-generation-inference streaming endpoint.
    """
    prompt = await _assemble_prompt(clone, trigger_message, db)
    url = f"{settings.AI_API_URL}/{settings.AI_MODEL_NAME}"
    payload = {
        "inputs": prompt,
        "parameters": {
            "max_new_tokens": settings.AI_MAX_NEW_TOKENS,
            "temperature": settings.AI_TEMPERATURE,
            "do_sample": True,
            "return_full_text": False,
        },
        "stream": True,
    }

    async with httpx.AsyncClient(timeout=settings.AI_TIMEOUT_SECONDS) as client:
        async with client.stream("POST", url, headers=_HF_HEADERS, json=payload) as resp:
            async for line in resp.aiter_lines():
                if line.startswith("data:"):
                    token = line[5:].strip()
                    if token and token != "[DONE]":
                        yield token
