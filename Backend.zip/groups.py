from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from sqlalchemy import select, delete
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.deps import get_current_user, get_db
from app.models.user import User
from app.models.message import Conversation, ConversationMember, ConversationType, MemberRole

router = APIRouter()


# ── Schemas ────────────────────────────────────────────────────────────────

class CreateGroupRequest(BaseModel):
    name: str
    member_ids: list[UUID]


class GroupOut(BaseModel):
    id: UUID
    name: str | None
    type: str
    created_at: str

    model_config = {"from_attributes": True}


class MemberOut(BaseModel):
    user_id: UUID
    role: str
    joined_at: str

    model_config = {"from_attributes": True}


class AddMemberRequest(BaseModel):
    user_id: UUID


# ── Routes ─────────────────────────────────────────────────────────────────

@router.post("/", response_model=GroupOut, status_code=status.HTTP_201_CREATED)
async def create_group(
    body: CreateGroupRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> Conversation:
    if len(body.name.strip()) < 2:
        raise HTTPException(status_code=400, detail="Group name too short")

    group = Conversation(
        type=ConversationType.group,
        name=body.name.strip(),
        created_by=current_user.id,
    )
    db.add(group)
    await db.flush()

    # Creator is admin
    members = [ConversationMember(
        conversation_id=group.id, user_id=current_user.id, role=MemberRole.admin
    )]

    # Validate and add requested members
    unique_ids = {uid for uid in body.member_ids if uid != current_user.id}
    for uid in unique_ids:
        user_q = await db.execute(select(User).where(User.id == uid))
        if not user_q.scalar_one_or_none():
            raise HTTPException(status_code=404, detail=f"User {uid} not found")
        members.append(ConversationMember(
            conversation_id=group.id, user_id=uid, role=MemberRole.member
        ))

    db.add_all(members)
    await db.commit()
    await db.refresh(group)
    return group


@router.get("/{group_id}/members", response_model=list[MemberOut])
async def get_members(
    group_id: UUID,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> list[ConversationMember]:
    await _assert_member(db, group_id, current_user.id)
    result = await db.execute(
        select(ConversationMember).where(ConversationMember.conversation_id == group_id)
    )
    return result.scalars().all()


@router.post("/{group_id}/members", status_code=status.HTTP_201_CREATED)
async def add_member(
    group_id: UUID,
    body: AddMemberRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> dict:
    await _assert_admin(db, group_id, current_user.id)

    # Check target exists
    user_q = await db.execute(select(User).where(User.id == body.user_id))
    if not user_q.scalar_one_or_none():
        raise HTTPException(status_code=404, detail="User not found")

    # Check not already a member
    existing = await db.execute(
        select(ConversationMember).where(
            ConversationMember.conversation_id == group_id,
            ConversationMember.user_id == body.user_id,
        )
    )
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=409, detail="Already a member")

    db.add(ConversationMember(
        conversation_id=group_id, user_id=body.user_id, role=MemberRole.member
    ))
    await db.commit()
    return {"detail": "Member added"}


@router.delete("/{group_id}/members/{user_id}", status_code=status.HTTP_204_NO_CONTENT)
async def remove_member(
    group_id: UUID,
    user_id: UUID,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> None:
    # Admins can remove anyone; members can remove only themselves
    if user_id != current_user.id:
        await _assert_admin(db, group_id, current_user.id)

    result = await db.execute(
        select(ConversationMember).where(
            ConversationMember.conversation_id == group_id,
            ConversationMember.user_id == user_id,
        )
    )
    member = result.scalar_one_or_none()
    if not member:
        raise HTTPException(status_code=404, detail="Member not found")
    await db.delete(member)
    await db.commit()


# ── Internal helpers ───────────────────────────────────────────────────────

async def _assert_member(db: AsyncSession, group_id: UUID, user_id: UUID) -> None:
    q = await db.execute(
        select(ConversationMember).where(
            ConversationMember.conversation_id == group_id,
            ConversationMember.user_id == user_id,
        )
    )
    if not q.scalar_one_or_none():
        raise HTTPException(status_code=403, detail="Not a member of this group")


async def _assert_admin(db: AsyncSession, group_id: UUID, user_id: UUID) -> None:
    q = await db.execute(
        select(ConversationMember).where(
            ConversationMember.conversation_id == group_id,
            ConversationMember.user_id == user_id,
            ConversationMember.role == MemberRole.admin,
        )
    )
    if not q.scalar_one_or_none():
        raise HTTPException(status_code=403, detail="Admin permission required")
