from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel
from sqlalchemy import select, desc
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.core.deps import get_current_user, get_db
from app.models.user import User
from app.models.message import Conversation, ConversationMember, ConversationType, Message, MemberRole

router = APIRouter()


# ── Schemas ────────────────────────────────────────────────────────────────

class ConversationOut(BaseModel):
    id: UUID
    type: str
    name: str | None
    created_at: str

    model_config = {"from_attributes": True}


class MessageOut(BaseModel):
    id: UUID
    conversation_id: UUID
    sender_user_id: UUID | None
    sender_clone_id: UUID | None
    content: str
    is_ai_generated: bool
    reply_to_id: UUID | None
    seen_by: list[UUID]
    created_at: str

    model_config = {"from_attributes": True}


class CreateDirectChatRequest(BaseModel):
    target_user_id: UUID


# ── Routes ─────────────────────────────────────────────────────────────────

@router.post("/direct", response_model=ConversationOut, status_code=status.HTTP_201_CREATED)
async def create_direct_chat(
    body: CreateDirectChatRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> Conversation:
    if body.target_user_id == current_user.id:
        raise HTTPException(status_code=400, detail="Cannot chat with yourself")

    # Check target user exists
    target = await db.execute(select(User).where(User.id == body.target_user_id))
    if not target.scalar_one_or_none():
        raise HTTPException(status_code=404, detail="User not found")

    # Check if DM already exists between these two users
    existing = await db.execute(
        select(Conversation)
        .join(ConversationMember, ConversationMember.conversation_id == Conversation.id)
        .where(
            Conversation.type == ConversationType.direct,
            ConversationMember.user_id == current_user.id,
        )
    )
    for conv in existing.scalars().all():
        members_q = await db.execute(
            select(ConversationMember).where(
                ConversationMember.conversation_id == conv.id,
                ConversationMember.user_id == body.target_user_id,
            )
        )
        if members_q.scalar_one_or_none():
            return conv  # already exists

    conversation = Conversation(type=ConversationType.direct, created_by=current_user.id)
    db.add(conversation)
    await db.flush()

    db.add_all([
        ConversationMember(conversation_id=conversation.id, user_id=current_user.id, role=MemberRole.admin),
        ConversationMember(conversation_id=conversation.id, user_id=body.target_user_id, role=MemberRole.member),
    ])
    await db.commit()
    await db.refresh(conversation)
    return conversation


@router.get("/", response_model=list[ConversationOut])
async def list_conversations(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> list[Conversation]:
    result = await db.execute(
        select(Conversation)
        .join(ConversationMember, ConversationMember.conversation_id == Conversation.id)
        .where(ConversationMember.user_id == current_user.id)
        .order_by(desc(Conversation.created_at))
    )
    return result.scalars().all()


@router.get("/{conversation_id}/messages", response_model=list[MessageOut])
async def get_messages(
    conversation_id: UUID,
    limit: int = Query(50, le=200),
    before_id: UUID | None = Query(None),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> list[Message]:
    # Auth check
    member = await db.execute(
        select(ConversationMember).where(
            ConversationMember.conversation_id == conversation_id,
            ConversationMember.user_id == current_user.id,
        )
    )
    if not member.scalar_one_or_none():
        raise HTTPException(status_code=403, detail="Not a member of this conversation")

    query = (
        select(Message)
        .where(Message.conversation_id == conversation_id)
        .order_by(desc(Message.created_at))
        .limit(limit)
    )
    if before_id:
        cursor_q = await db.execute(select(Message).where(Message.id == before_id))
        cursor = cursor_q.scalar_one_or_none()
        if cursor:
            query = query.where(Message.created_at < cursor.created_at)

    result = await db.execute(query)
    messages = result.scalars().all()
    return list(reversed(messages))  # chronological order for client


@router.delete("/{conversation_id}", status_code=status.HTTP_204_NO_CONTENT)
async def leave_conversation(
    conversation_id: UUID,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> None:
    member_q = await db.execute(
        select(ConversationMember).where(
            ConversationMember.conversation_id == conversation_id,
            ConversationMember.user_id == current_user.id,
        )
    )
    member = member_q.scalar_one_or_none()
    if not member:
        raise HTTPException(status_code=404, detail="Membership not found")
    await db.delete(member)
    await db.commit()
