"""
WebSocket handlers
ws://host/ws/chat/{conversation_id}?token=<jwt>

Incoming event shapes:
  { "type": "message",      "content": "...", "reply_to_id": null }
  { "type": "typing",       "is_typing": true }
  { "type": "seen",         "message_id": "..." }
"""

import asyncio
import logging
from uuid import UUID

from fastapi import APIRouter, Depends, WebSocket, WebSocketDisconnect
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update

from app.core.deps import get_db, get_ws_user
from app.models.user import User
from app.models.message import Conversation, ConversationMember, Message
from app.models.ai_clone import AIClone
from app.ws.manager import manager, EVT_ERROR
from app.services.ai_service import generate_clone_reply
from app.core.config import settings

log = logging.getLogger(__name__)
router = APIRouter()


# ── Helpers ────────────────────────────────────────────────────────────────

async def _assert_member(
    db: AsyncSession, conversation_id: UUID, user_id: UUID
) -> bool:
    result = await db.execute(
        select(ConversationMember).where(
            ConversationMember.conversation_id == conversation_id,
            ConversationMember.user_id == user_id,
        )
    )
    return result.scalar_one_or_none() is not None


async def _save_message(
    db: AsyncSession,
    conversation_id: UUID,
    sender_user_id: UUID | None,
    sender_clone_id: UUID | None,
    content: str,
    reply_to_id: UUID | None,
    is_ai: bool = False,
) -> Message:
    msg = Message(
        conversation_id=conversation_id,
        sender_user_id=sender_user_id,
        sender_clone_id=sender_clone_id,
        content=content,
        reply_to_id=reply_to_id,
        is_ai_generated=is_ai,
        seen_by=[sender_user_id] if sender_user_id else [],
    )
    db.add(msg)
    await db.commit()
    await db.refresh(msg)
    return msg


def _message_payload(msg: Message, sender_username: str) -> dict:
    return {
        "id": str(msg.id),
        "conversation_id": str(msg.conversation_id),
        "sender_user_id": str(msg.sender_user_id) if msg.sender_user_id else None,
        "sender_clone_id": str(msg.sender_clone_id) if msg.sender_clone_id else None,
        "sender_username": sender_username,
        "content": msg.content,
        "is_ai_generated": msg.is_ai_generated,
        "reply_to_id": str(msg.reply_to_id) if msg.reply_to_id else None,
        "seen_by": [str(u) for u in msg.seen_by],
        "created_at": msg.created_at.isoformat(),
    }


async def _maybe_trigger_clone(
    db: AsyncSession,
    conversation_id: UUID,
    incoming_message: Message,
    room_id: str,
) -> None:
    """
    For each offline member in the conversation that has an active clone,
    wait CLONE_OFFLINE_DELAY_SECONDS then reply as that clone.
    """
    result = await db.execute(
        select(ConversationMember).where(
            ConversationMember.conversation_id == conversation_id
        )
    )
    members = result.scalars().all()

    for member in members:
        if str(member.user_id) == str(incoming_message.sender_user_id):
            continue  # don't reply to yourself
        if manager.is_user_online_in_room(room_id, str(member.user_id)):
            continue  # user is online, no clone needed

        # Load clone for this offline user
        clone_result = await db.execute(
            select(AIClone).where(
                AIClone.user_id == member.user_id,
                AIClone.is_active == True,  # noqa: E712
            )
        )
        clone: AIClone | None = clone_result.scalar_one_or_none()
        if clone is None:
            continue

        # Schedule reply with delay (non-blocking)
        asyncio.create_task(
            _delayed_clone_reply(
                conversation_id=conversation_id,
                clone=clone,
                trigger_message=incoming_message.content,
                room_id=room_id,
            )
        )


async def _delayed_clone_reply(
    conversation_id: UUID,
    clone: AIClone,
    trigger_message: str,
    room_id: str,
) -> None:
    await asyncio.sleep(settings.CLONE_OFFLINE_DELAY_SECONDS)

    from app.db.session import AsyncSessionLocal
    async with AsyncSessionLocal() as db:
        try:
            reply_text = await generate_clone_reply(
                clone=clone,
                trigger_message=trigger_message,
                db=db,
            )
            msg = await _save_message(
                db=db,
                conversation_id=conversation_id,
                sender_user_id=None,
                sender_clone_id=clone.id,
                content=reply_text,
                reply_to_id=None,
                is_ai=True,
            )
            await manager.emit_clone_message(
                room_id,
                _message_payload(msg, sender_username=clone.name),
            )
        except Exception as exc:
            log.exception("Clone reply failed clone=%s: %s", clone.id, exc)


# ── WebSocket endpoint ─────────────────────────────────────────────────────

@router.websocket("/ws/chat/{conversation_id}")
async def websocket_chat(
    websocket: WebSocket,
    conversation_id: UUID,
    current_user: User = Depends(get_ws_user),
    db: AsyncSession = Depends(get_db),
) -> None:
    room_id = str(conversation_id)

    # Auth — must be a member
    if not await _assert_member(db, conversation_id, current_user.id):
        await websocket.close(code=4003)
        return

    await manager.connect(websocket, room_id, str(current_user.id))

    # Mark user online
    await db.execute(
        update(User).where(User.id == current_user.id).values(is_online=True)
    )
    await db.commit()

    try:
        while True:
            data: dict = await websocket.receive_json()
            event_type: str = data.get("type", "")

            # ── Typing indicator ───────────────────────────────────────────
            if event_type == "typing":
                await manager.emit_typing(
                    room_id, str(current_user.id), is_typing=data.get("is_typing", True)
                )

            # ── Seen receipt ───────────────────────────────────────────────
            elif event_type == "seen":
                message_id = data.get("message_id")
                if message_id:
                    msg_result = await db.execute(
                        select(Message).where(Message.id == UUID(message_id))
                    )
                    msg: Message | None = msg_result.scalar_one_or_none()
                    if msg and current_user.id not in msg.seen_by:
                        msg.seen_by = [*msg.seen_by, current_user.id]
                        await db.commit()
                    await manager.emit_seen(room_id, message_id, str(current_user.id))

            # ── New message ────────────────────────────────────────────────
            elif event_type == "message":
                content: str = (data.get("content") or "").strip()
                if not content:
                    await manager.send_personal(websocket, {
                        "type": EVT_ERROR, "detail": "Empty message"
                    })
                    continue

                reply_to_raw = data.get("reply_to_id")
                reply_to_id = UUID(reply_to_raw) if reply_to_raw else None

                msg = await _save_message(
                    db=db,
                    conversation_id=conversation_id,
                    sender_user_id=current_user.id,
                    sender_clone_id=None,
                    content=content,
                    reply_to_id=reply_to_id,
                )

                await manager.emit_message(
                    room_id,
                    _message_payload(msg, sender_username=current_user.username),
                )

                # Possibly trigger AI clone replies for offline members
                await _maybe_trigger_clone(db, conversation_id, msg, room_id)

            else:
                await manager.send_personal(websocket, {
                    "type": EVT_ERROR, "detail": f"Unknown event type: {event_type}"
                })

    except WebSocketDisconnect:
        pass
    except Exception as exc:
        log.exception("WS error user=%s: %s", current_user.id, exc)
    finally:
        await manager.disconnect(websocket, room_id)
        # Mark offline + update last_seen
        from datetime import datetime, timezone
        await db.execute(
            update(User).where(User.id == current_user.id).values(
                is_online=False,
                last_seen=datetime.now(timezone.utc),
            )
        )
        await db.commit()
