"""
WebSocket Connection Manager
- Tracks active connections per room (conversation_id)
- Uses Redis pub/sub for multi-process fan-out
- Exposes broadcast, send_personal, typing event helpers
"""

import asyncio
import json
import logging
from collections import defaultdict
from typing import Any
from uuid import UUID

import redis.asyncio as aioredis
from fastapi import WebSocket

from app.core.config import settings

log = logging.getLogger(__name__)

# ── Event type constants ───────────────────────────────────────────────────

EVT_MESSAGE   = "message"
EVT_TYPING    = "typing"
EVT_STOP_TYPE = "stop_typing"
EVT_PRESENCE  = "presence"
EVT_SEEN      = "seen"
EVT_CLONE_MSG = "clone_message"
EVT_ERROR     = "error"


class ConnectionManager:
    def __init__(self) -> None:
        # room_id (str) → set of WebSocket connections
        self._rooms: dict[str, set[WebSocket]] = defaultdict(set)
        # ws → user_id mapping
        self._ws_user: dict[WebSocket, str] = {}
        # Redis client (lazy init)
        self._redis: aioredis.Redis | None = None
        self._pubsub_task: asyncio.Task | None = None

    # ── Redis ──────────────────────────────────────────────────────────────

    async def _get_redis(self) -> aioredis.Redis:
        if self._redis is None:
            self._redis = await aioredis.from_url(
                settings.REDIS_URL, decode_responses=True
            )
        return self._redis

    async def start_pubsub_listener(self) -> None:
        """Subscribe to Redis channel and fan out to local WS connections."""
        redis = await self._get_redis()
        pubsub = redis.pubsub()
        await pubsub.subscribe("ws:broadcast")
        self._pubsub_task = asyncio.create_task(self._listen(pubsub))
        log.info("WebSocket Redis pub/sub listener started")

    async def _listen(self, pubsub) -> None:
        async for raw in pubsub.listen():
            if raw["type"] != "message":
                continue
            try:
                envelope: dict = json.loads(raw["data"])
                room_id: str = envelope["room_id"]
                payload: dict = envelope["payload"]
                exclude_ws: str | None = envelope.get("exclude_ws")
                await self._local_broadcast(room_id, payload, exclude_ws)
            except Exception as exc:
                log.exception("pub/sub dispatch error: %s", exc)

    # ── Connection lifecycle ───────────────────────────────────────────────

    async def connect(self, ws: WebSocket, room_id: str, user_id: str) -> None:
        await ws.accept()
        self._rooms[room_id].add(ws)
        self._ws_user[ws] = user_id
        log.debug("WS connect  user=%s room=%s", user_id, room_id)
        # Announce presence
        await self._publish(room_id, {
            "type": EVT_PRESENCE,
            "user_id": user_id,
            "online": True,
        })

    async def disconnect(self, ws: WebSocket, room_id: str) -> None:
        user_id = self._ws_user.pop(ws, None)
        self._rooms[room_id].discard(ws)
        if not self._rooms[room_id]:
            del self._rooms[room_id]
        log.debug("WS disconnect user=%s room=%s", user_id, room_id)
        if user_id:
            await self._publish(room_id, {
                "type": EVT_PRESENCE,
                "user_id": user_id,
                "online": False,
            })

    # ── Broadcast helpers ──────────────────────────────────────────────────

    async def broadcast(
        self,
        room_id: str,
        payload: dict[str, Any],
        exclude_ws: WebSocket | None = None,
    ) -> None:
        """Publish to Redis so ALL server instances fan out."""
        await self._publish(
            room_id,
            payload,
            exclude_ws=id(exclude_ws) if exclude_ws else None,
        )

    async def _publish(
        self,
        room_id: str,
        payload: dict[str, Any],
        exclude_ws: int | None = None,
    ) -> None:
        envelope = {"room_id": room_id, "payload": payload, "exclude_ws": exclude_ws}
        redis = await self._get_redis()
        await redis.publish("ws:broadcast", json.dumps(envelope, default=str))

    async def _local_broadcast(
        self,
        room_id: str,
        payload: dict[str, Any],
        exclude_ws_id: str | None,
    ) -> None:
        dead: list[WebSocket] = []
        for ws in list(self._rooms.get(room_id, [])):
            if exclude_ws_id and str(id(ws)) == str(exclude_ws_id):
                continue
            try:
                await ws.send_json(payload)
            except Exception:
                dead.append(ws)
        for ws in dead:
            self._rooms[room_id].discard(ws)

    async def send_personal(self, ws: WebSocket, payload: dict[str, Any]) -> None:
        try:
            await ws.send_json(payload)
        except Exception as exc:
            log.warning("send_personal failed: %s", exc)

    # ── Typed event senders ────────────────────────────────────────────────

    async def emit_typing(self, room_id: str, user_id: str, is_typing: bool) -> None:
        await self.broadcast(room_id, {
            "type": EVT_TYPING if is_typing else EVT_STOP_TYPE,
            "user_id": user_id,
            "room_id": room_id,
        })

    async def emit_message(self, room_id: str, message: dict[str, Any]) -> None:
        await self.broadcast(room_id, {"type": EVT_MESSAGE, **message})

    async def emit_clone_message(self, room_id: str, message: dict[str, Any]) -> None:
        await self.broadcast(room_id, {"type": EVT_CLONE_MSG, **message})

    async def emit_seen(self, room_id: str, message_id: str, user_id: str) -> None:
        await self.broadcast(room_id, {
            "type": EVT_SEEN,
            "message_id": message_id,
            "user_id": user_id,
            "room_id": room_id,
        })

    # ── Presence query ─────────────────────────────────────────────────────

    def online_user_ids(self, room_id: str) -> set[str]:
        return {self._ws_user[ws] for ws in self._rooms.get(room_id, [])}

    def is_user_online_in_room(self, room_id: str, user_id: str) -> bool:
        return user_id in self.online_user_ids(room_id)


# Singleton — imported everywhere
manager = ConnectionManager()
