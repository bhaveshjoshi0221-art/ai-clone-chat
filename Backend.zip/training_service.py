"""
Training Service
Analyses stored training sessions to rebuild the clone's personality_prompt
and update the style_vector (tone, avg reply length, top words).
"""

import logging
import re
from collections import Counter

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.ai_clone import AIClone, TrainingSession

log = logging.getLogger(__name__)

# Words to exclude from top-words analysis
_STOP_WORDS = {
    "i", "me", "my", "we", "you", "your", "the", "a", "an", "is", "it",
    "in", "on", "to", "and", "of", "that", "this", "for", "with", "be",
    "was", "are", "at", "by", "as", "so", "do", "up", "he", "she", "they",
    "but", "or", "if", "no", "yes", "ok", "not", "just", "have", "get",
    "got", "will", "can", "would", "could", "should", "ll", "re", "ve",
    "don", "didn", "won", "let", "how", "what", "when", "where", "why",
}

_MAX_SESSIONS_FOR_ANALYSIS = 100
_TOP_WORDS_COUNT = 20


# ── Style analysis helpers ─────────────────────────────────────────────────

def _detect_tone(responses: list[str]) -> str:
    """Heuristic tone classification from response corpus."""
    text = " ".join(responses).lower()
    total_words = len(text.split())
    if total_words == 0:
        return "neutral"

    emoji_count = len(re.findall(r"[^\w\s,.]", text))
    question_ratio = text.count("?") / max(len(responses), 1)
    exclamation_ratio = text.count("!") / max(len(responses), 1)
    lol_count = text.count("lol") + text.count("haha") + text.count("lmao")

    if emoji_count > len(responses) * 0.5 or lol_count > len(responses) * 0.3:
        return "casual and expressive"
    if exclamation_ratio > 0.6:
        return "enthusiastic"
    if question_ratio > 0.4:
        return "inquisitive"
    avg_len = sum(len(r.split()) for r in responses) / len(responses)
    if avg_len > 40:
        return "detailed and articulate"
    if avg_len < 8:
        return "brief and direct"
    return "conversational"


def _extract_top_words(responses: list[str]) -> list[str]:
    words = re.findall(r"\b[a-z]{3,}\b", " ".join(responses).lower())
    filtered = [w for w in words if w not in _STOP_WORDS]
    most_common = Counter(filtered).most_common(_TOP_WORDS_COUNT)
    return [word for word, _ in most_common]


def _average_reply_length(responses: list[str]) -> int:
    if not responses:
        return 0
    return round(sum(len(r.split()) for r in responses) / len(responses))


# ── Prompt builder ─────────────────────────────────────────────────────────

def _build_prompt(
    clone_name: str,
    tone: str,
    avg_length: int,
    top_words: list[str],
    sample_responses: list[str],
) -> str:
    word_sample = ", ".join(top_words[:10]) if top_words else "none identified"
    length_guidance = (
        "very short (1–2 sentences)"
        if avg_length < 10 else
        "medium length (2–4 sentences)"
        if avg_length < 30 else
        "longer and detailed (4+ sentences)"
    )

    examples = ""
    if sample_responses:
        picks = sample_responses[-3:]  # three most recent
        examples = "\n\nExample responses from this person:\n" + "\n".join(
            f'- "{r}"' for r in picks
        )

    return (
        f"You are {clone_name}, an AI clone that mimics a specific person's texting style.\n\n"
        f"Communication style:\n"
        f"- Tone: {tone}\n"
        f"- Reply length: {length_guidance} (avg {avg_length} words)\n"
        f"- Frequently used words: {word_sample}\n"
        f"- Stay in character at all times. Do not break the persona.\n"
        f"- Do not mention being an AI unless directly and seriously asked.\n"
        f"- Mirror the person's vocabulary, punctuation habits, and energy level."
        f"{examples}"
    )


# ── Public interface ───────────────────────────────────────────────────────

async def rebuild_personality_prompt(clone: AIClone, db: AsyncSession) -> str:
    """
    Reads training sessions for this clone, derives style_vector,
    rebuilds and returns the new personality_prompt.
    Also persists the updated style_vector onto the clone object (caller commits).
    """
    result = await db.execute(
        select(TrainingSession)
        .where(TrainingSession.clone_id == clone.id)
        .order_by(TrainingSession.created_at.desc())
        .limit(_MAX_SESSIONS_FOR_ANALYSIS)
    )
    sessions: list[TrainingSession] = result.scalars().all()

    if not sessions:
        log.info("No training sessions for clone=%s, keeping default prompt", clone.id)
        return clone.personality_prompt

    responses = [s.response for s in sessions]

    tone = _detect_tone(responses)
    avg_length = _average_reply_length(responses)
    top_words = _extract_top_words(responses)

    # Persist style_vector
    clone.style_vector = {
        "tone": tone,
        "avg_reply_length": avg_length,
        "top_words": top_words,
    }

    prompt = _build_prompt(
        clone_name=clone.name,
        tone=tone,
        avg_length=avg_length,
        top_words=top_words,
        sample_responses=responses[:10],
    )

    log.info(
        "Rebuilt prompt for clone=%s tone=%r avg_len=%d top_words=%s",
        clone.id, tone, avg_length, top_words[:5],
    )
    return prompt
