from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.deps import get_current_user, get_db
from app.models.user import User
from app.models.ai_clone import AIClone

router = APIRouter()


# ── Schemas ────────────────────────────────────────────────────────────────

class CloneOut(BaseModel):
    id: UUID
    user_id: UUID
    name: str
    personality_prompt: str
    style_vector: dict
    training_turns: int
    is_active: bool
    updated_at: str

    model_config = {"from_attributes": True}


class UpdateCloneRequest(BaseModel):
    name: str | None = None
    personality_prompt: str | None = None
    is_active: bool | None = None


# ── Routes ─────────────────────────────────────────────────────────────────

@router.get("/me", response_model=CloneOut)
async def get_my_clone(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> AIClone:
    clone = await _get_clone_for_user(db, current_user.id)
    return clone


@router.patch("/me", response_model=CloneOut)
async def update_my_clone(
    body: UpdateCloneRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> AIClone:
    clone = await _get_clone_for_user(db, current_user.id)

    if body.name is not None:
        clone.name = body.name
    if body.personality_prompt is not None:
        clone.personality_prompt = body.personality_prompt
    if body.is_active is not None:
        clone.is_active = body.is_active

    await db.commit()
    await db.refresh(clone)
    return clone


@router.get("/{user_id}", response_model=CloneOut)
async def get_user_clone(
    user_id: UUID,
    db: AsyncSession = Depends(get_db),
    _: User = Depends(get_current_user),
) -> AIClone:
    clone = await _get_clone_for_user(db, user_id)
    return clone


# ── Helpers ────────────────────────────────────────────────────────────────

async def _get_clone_for_user(db: AsyncSession, user_id: UUID) -> AIClone:
    result = await db.execute(
        select(AIClone).where(AIClone.user_id == user_id)
    )
    clone: AIClone | None = result.scalar_one_or_none()
    if not clone:
        raise HTTPException(status_code=404, detail="Clone not found for this user")
    return clone
