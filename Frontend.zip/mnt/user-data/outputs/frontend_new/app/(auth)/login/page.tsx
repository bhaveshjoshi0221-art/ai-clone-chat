"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { motion } from "framer-motion";
import { Zap, Eye, EyeOff, ArrowRight, Loader2 } from "lucide-react";
import { api } from "@/lib/api";
import { useChatStore } from "@/store/chatStore";
import clsx from "clsx";

export default function LoginPage() {
  const router = useRouter();
  const setAuth = useChatStore((s) => s.setAuth);

  const [form, setForm] = useState({ email: "", password: "" });
  const [showPw, setShowPw] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const tokens = await api.login({ email: form.email, password: form.password });
      localStorage.setItem("access_token", tokens.access_token);
      localStorage.setItem("refresh_token", tokens.refresh_token);
      const user = await api.me();
      setAuth(tokens.access_token, user);
      router.push("/chats");
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : "Invalid credentials");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-void flex items-center justify-center px-4 relative overflow-hidden">
      {/* Background glow */}
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] rounded-full bg-violet/5 blur-[120px] pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 w-[300px] h-[300px] rounded-full bg-cyan/5 blur-[100px] pointer-events-none" />

      <motion.div
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.35, ease: "easeOut" }}
        className="w-full max-w-[400px]"
      >
        {/* Logo */}
        <div className="flex flex-col items-center mb-8">
          <div className="w-14 h-14 rounded-2xl bg-bubble-me flex items-center justify-center shadow-violet-glow mb-4">
            <Zap size={24} className="text-white" fill="white" />
          </div>
          <h1 className="text-[26px] font-[750] tracking-tight text-light">
            Clone<span className="text-violet">Chat</span>
          </h1>
          <p className="text-dim text-[13.5px] mt-1">Your AI-powered social layer</p>
        </div>

        {/* Form card */}
        <div className="gradient-border bg-card rounded-3xl p-6 space-y-4">
          <h2 className="text-[17px] font-[650] text-light mb-1">Sign in</h2>

          {error && (
            <motion.div
              initial={{ opacity: 0, y: -4 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-red-500/10 border border-red-500/20 rounded-xl px-4 py-2.5 text-[13px] text-red-400"
            >
              {error}
            </motion.div>
          )}

          <form onSubmit={handleSubmit} className="space-y-3">
            {/* Email */}
            <div>
              <label className="text-[11.5px] font-[550] text-dim uppercase tracking-wider block mb-1.5">
                Email
              </label>
              <input
                type="email"
                required
                value={form.email}
                onChange={(e) => setForm((p) => ({ ...p, email: e.target.value }))}
                placeholder="you@example.com"
                className="w-full bg-surface border border-border rounded-xl px-4 py-3 text-[14px] text-light placeholder:text-muted focus:border-violet/50 focus:shadow-input-focus transition-all outline-none"
              />
            </div>

            {/* Password */}
            <div>
              <label className="text-[11.5px] font-[550] text-dim uppercase tracking-wider block mb-1.5">
                Password
              </label>
              <div className="relative">
                <input
                  type={showPw ? "text" : "password"}
                  required
                  value={form.password}
                  onChange={(e) => setForm((p) => ({ ...p, password: e.target.value }))}
                  placeholder="••••••••"
                  className="w-full bg-surface border border-border rounded-xl px-4 py-3 pr-11 text-[14px] text-light placeholder:text-muted focus:border-violet/50 focus:shadow-input-focus transition-all outline-none"
                />
                <button
                  type="button"
                  onClick={() => setShowPw(!showPw)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted hover:text-soft transition-colors"
                >
                  {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            {/* Submit */}
            <motion.button
              type="submit"
              disabled={loading}
              whileTap={{ scale: 0.98 }}
              className={clsx(
                "w-full flex items-center justify-center gap-2 py-3.5 rounded-2xl mt-2",
                "text-[14.5px] font-[650] text-white",
                "bg-bubble-me shadow-violet-glow/40 hover:opacity-90 transition-opacity",
                "disabled:opacity-60 disabled:cursor-not-allowed"
              )}
            >
              {loading ? (
                <Loader2 size={17} className="animate-spin" />
              ) : (
                <>Sign in <ArrowRight size={16} /></>
              )}
            </motion.button>
          </form>

          <p className="text-center text-[13px] text-dim pt-1">
            No account?{" "}
            <Link href="/register" className="text-violet-light hover:text-violet font-[550] transition-colors">
              Create one
            </Link>
          </p>
        </div>
      </motion.div>
    </div>
  );
}
