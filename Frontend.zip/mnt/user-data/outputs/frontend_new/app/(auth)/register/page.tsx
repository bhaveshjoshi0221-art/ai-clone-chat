"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { motion } from "framer-motion";
import { Zap, ArrowRight, Loader2 } from "lucide-react";
import { api } from "@/lib/api";
import { useChatStore } from "@/store/chatStore";
import clsx from "clsx";

export default function RegisterPage() {
  const router = useRouter();
  const setAuth = useChatStore((s) => s.setAuth);

  const [form, setForm] = useState({ username: "", email: "", password: "" });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const tokens = await api.register(form);
      localStorage.setItem("access_token", tokens.access_token);
      localStorage.setItem("refresh_token", tokens.refresh_token);
      const user = await api.me();
      setAuth(tokens.access_token, user);
      router.push("/chats");
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : "Registration failed");
    } finally {
      setLoading(false);
    }
  };

  const fields = [
    { key: "username", label: "Username", type: "text",     placeholder: "yourname"          },
    { key: "email",    label: "Email",    type: "email",    placeholder: "you@example.com"   },
    { key: "password", label: "Password", type: "password", placeholder: "Min 8 characters"  },
  ] as const;

  return (
    <div className="min-h-screen bg-void flex items-center justify-center px-4 relative overflow-hidden">
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] rounded-full bg-cyan/5 blur-[120px] pointer-events-none" />

      <motion.div
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.35 }}
        className="w-full max-w-[400px]"
      >
        <div className="flex flex-col items-center mb-8">
          <div className="w-14 h-14 rounded-2xl bg-bubble-me flex items-center justify-center shadow-violet-glow mb-4">
            <Zap size={24} className="text-white" fill="white" />
          </div>
          <h1 className="text-[26px] font-[750] tracking-tight text-light">
            Clone<span className="text-violet">Chat</span>
          </h1>
          <p className="text-dim text-[13.5px] mt-1">Create your account & AI clone</p>
        </div>

        <div className="gradient-border bg-card rounded-3xl p-6 space-y-4">
          <h2 className="text-[17px] font-[650] text-light mb-1">Get started</h2>

          {error && (
            <motion.div
              initial={{ opacity: 0, y: -4 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-red-500/10 border border-red-500/20 rounded-xl px-4 py-2.5 text-[13px] text-red-400"
            >
              {error}
            </motion.div>
          )}

          <form onSubmit={handleSubmit} className="space-y-3">
            {fields.map(({ key, label, type, placeholder }) => (
              <div key={key}>
                <label className="text-[11.5px] font-[550] text-dim uppercase tracking-wider block mb-1.5">
                  {label}
                </label>
                <input
                  type={type}
                  required
                  value={form[key]}
                  onChange={(e) => setForm((p) => ({ ...p, [key]: e.target.value }))}
                  placeholder={placeholder}
                  className="w-full bg-surface border border-border rounded-xl px-4 py-3 text-[14px] text-light placeholder:text-muted focus:border-violet/50 focus:shadow-input-focus transition-all outline-none"
                />
              </div>
            ))}

            <motion.button
              type="submit"
              disabled={loading}
              whileTap={{ scale: 0.98 }}
              className={clsx(
                "w-full flex items-center justify-center gap-2 py-3.5 rounded-2xl mt-2",
                "text-[14.5px] font-[650] text-white",
                "bg-bubble-me shadow-violet-glow/40 hover:opacity-90 transition-opacity",
                "disabled:opacity-60 disabled:cursor-not-allowed"
              )}
            >
              {loading ? <Loader2 size={17} className="animate-spin" /> : <><ArrowRight size={16} /> Create account</>}
            </motion.button>
          </form>

          <p className="text-center text-[13px] text-dim pt-1">
            Already have one?{" "}
            <Link href="/login" className="text-violet-light hover:text-violet font-[550] transition-colors">
              Sign in
            </Link>
          </p>
        </div>
      </motion.div>
    </div>
  );
}
