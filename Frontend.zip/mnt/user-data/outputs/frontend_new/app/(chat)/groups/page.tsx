"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import { Users, Plus, Check, X, Loader2 } from "lucide-react";
import { api, type UserOut, type ConversationOut } from "@/lib/api";
import { useChatStore } from "@/store/chatStore";
import clsx from "clsx";

export default function GroupsPage() {
  const router = useRouter();
  const { conversations, setConversations, currentUser } = useChatStore();
  const [users, setUsers] = useState<UserOut[]>([]);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [groupName, setGroupName] = useState("");
  const [creating, setCreating] = useState(false);
  const [showForm, setShowForm] = useState(false);

  const groups = conversations.filter((c) => c.type === "group");

  useEffect(() => {
    api.listUsers().then((u) =>
      setUsers(u.filter((x) => x.id !== currentUser?.id))
    ).catch(() => {});
  }, []);

  const toggle = (id: string) => {
    setSelected((p) => {
      const s = new Set(p);
      s.has(id) ? s.delete(id) : s.add(id);
      return s;
    });
  };

  const handleCreate = async () => {
    if (!groupName.trim() || selected.size === 0) return;
    setCreating(true);
    try {
      await api.createGroup({ name: groupName.trim(), member_ids: [...selected] });
      const updated = await api.listConversations();
      setConversations(updated);
      const newGroup = updated.find((c) => c.type === "group" && c.name === groupName.trim());
      if (newGroup) router.push(`/chats/${newGroup.id}`);
    } finally {
      setCreating(false);
      setShowForm(false);
      setSelected(new Set());
      setGroupName("");
    }
  };

  return (
    <div className="flex flex-col h-full bg-void">
      {/* Header */}
      <header className="flex items-center gap-3 px-5 py-4 glass border-b border-border/50">
        <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-cyan/60 to-teal-700 flex items-center justify-center">
          <Users size={17} className="text-white" />
        </div>
        <h1 className="flex-1 text-[15px] font-[700] text-light">Groups</h1>
        <button
          onClick={() => setShowForm(!showForm)}
          className="w-9 h-9 rounded-full bg-bubble-me flex items-center justify-center shadow-violet-glow/40 hover:scale-105 transition-transform"
        >
          <Plus size={18} className="text-white" strokeWidth={2.5} />
        </button>
      </header>

      {/* Create form */}
      <AnimatePresence>
        {showForm && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden border-b border-border/50"
          >
            <div className="px-4 py-4 space-y-3 bg-card/50">
              <p className="text-[11px] text-violet-light font-semibold uppercase tracking-wider">New group</p>
              <input
                value={groupName}
                onChange={(e) => setGroupName(e.target.value)}
                placeholder="Group name…"
                className="w-full bg-surface border border-border rounded-xl px-4 py-2.5 text-[13.5px] text-light placeholder:text-muted focus:border-violet/50 outline-none transition-all"
              />
              <p className="text-[11px] text-dim font-[550]">Add members</p>
              <div className="flex flex-wrap gap-2 max-h-[120px] overflow-y-auto">
                {users.map((u) => (
                  <button
                    key={u.id}
                    onClick={() => toggle(u.id)}
                    className={clsx(
                      "flex items-center gap-1.5 px-3 py-1.5 rounded-full text-[12.5px] font-[500] transition-all border",
                      selected.has(u.id)
                        ? "bg-violet/20 border-violet/40 text-violet-light"
                        : "bg-surface border-border text-dim hover:text-soft"
                    )}
                  >
                    {selected.has(u.id) ? <Check size={11} /> : null}
                    {u.username}
                  </button>
                ))}
              </div>
              <div className="flex gap-2 pt-1">
                <button
                  onClick={() => setShowForm(false)}
                  className="flex-1 py-2.5 rounded-xl border border-border text-[13px] text-dim hover:text-soft transition-colors"
                >
                  Cancel
                </button>
                <motion.button
                  onClick={handleCreate}
                  disabled={creating || !groupName.trim() || selected.size === 0}
                  whileTap={{ scale: 0.97 }}
                  className="flex-1 py-2.5 rounded-xl bg-bubble-me text-white text-[13px] font-[600] disabled:opacity-40 flex items-center justify-center gap-1.5"
                >
                  {creating ? <Loader2 size={14} className="animate-spin" /> : <>Create</>}
                </motion.button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Groups list */}
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-2">
        {groups.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex flex-col items-center justify-center py-20 text-center"
          >
            <Users size={40} className="text-muted mb-3" strokeWidth={1} />
            <p className="text-soft font-[550]">No groups yet</p>
            <p className="text-dim text-[13px] mt-1">Tap + to create one</p>
          </motion.div>
        )}
        {groups.map((g, i) => (
          <motion.div
            key={g.id}
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.05 }}
          >
            <Link
              href={`/chats/${g.id}`}
              className="flex items-center gap-3 px-4 py-3.5 rounded-2xl bg-card border border-border/50 hover:border-cyan/20 hover:bg-cyan/5 transition-all"
            >
              <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-cyan/50 to-teal-700 flex items-center justify-center text-[15px] font-bold">
                {(g.name ?? "G")[0].toUpperCase()}
              </div>
              <div>
                <p className="text-[14px] font-[600] text-light">{g.name}</p>
                <p className="text-[12px] text-dim">Group · Tap to open</p>
              </div>
            </Link>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
