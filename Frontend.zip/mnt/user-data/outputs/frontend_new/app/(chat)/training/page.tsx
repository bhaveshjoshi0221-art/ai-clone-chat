"use client";

import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Brain, Send, Sparkles, Trash2, RefreshCw, ChevronRight } from "lucide-react";
import { api } from "@/lib/api";
import clsx from "clsx";

interface Turn {
  id?: string;
  prompt: string;
  response: string;
}

interface Stats {
  total_turns: number;
  personality_prompt: string;
  clone_id: string;
}

export default function TrainingPage() {
  const [turns, setTurns] = useState<Turn[]>([]);
  const [stats, setStats] = useState<Stats | null>(null);
  const [prompt, setPrompt] = useState("");
  const [response, setResponse] = useState("");
  const [saving, setSaving] = useState(false);
  const [rebuilding, setRebuilding] = useState(false);
  const [showPrompt, setShowPrompt] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    Promise.all([
      api["training"] ? fetch("/api/v1/training/turns", {
        headers: { Authorization: `Bearer ${localStorage.getItem("access_token")}` }
      }).then(r => r.json()).catch(() => []) : Promise.resolve([]),
      fetch("/api/v1/training/stats", {
        headers: { Authorization: `Bearer ${localStorage.getItem("access_token")}` }
      }).then(r => r.json()).catch(() => null),
    ]).then(([t, s]) => {
      if (Array.isArray(t)) setTurns(t.slice(0, 20).reverse());
      if (s) setStats(s);
    });
  }, []);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [turns.length]);

  const handleSave = async () => {
    if (!prompt.trim() || !response.trim()) return;
    setSaving(true);
    try {
      const res = await fetch("/api/v1/training/turns", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${localStorage.getItem("access_token")}`,
        },
        body: JSON.stringify({ prompt: prompt.trim(), response: response.trim() }),
      });
      if (res.ok) {
        const newTurn = await res.json();
        setTurns((p) => [...p, newTurn]);
        setPrompt("");
        setResponse("");
        setStats((s) => s ? { ...s, total_turns: s.total_turns + 1 } : s);
      }
    } finally {
      setSaving(false);
    }
  };

  const handleRebuild = async () => {
    setRebuilding(true);
    try {
      const res = await fetch("/api/v1/training/rebuild-prompt", {
        method: "POST",
        headers: { Authorization: `Bearer ${localStorage.getItem("access_token")}` },
      });
      if (res.ok) {
        const data = await res.json();
        setStats(data);
      }
    } finally {
      setRebuilding(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-void">
      {/* Header */}
      <header className="flex items-center gap-3 px-5 py-4 glass border-b border-border/50 flex-shrink-0">
        <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-violet-500 to-cyan/60 flex items-center justify-center">
          <Brain size={18} className="text-white" />
        </div>
        <div className="flex-1">
          <h1 className="text-[15px] font-[700] text-light">Train Your Clone</h1>
          <p className="text-[11px] text-dim">
            {stats ? `${stats.total_turns} training turns` : "Loading…"}
          </p>
        </div>
        <button
          onClick={handleRebuild}
          disabled={rebuilding}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-violet/30 text-violet-light text-[12px] font-[550] hover:bg-violet/10 transition-colors disabled:opacity-50"
        >
          <RefreshCw size={12} className={clsx(rebuilding && "animate-spin")} />
          Rebuild
        </button>
      </header>

      {/* Stats bar */}
      {stats && (
        <div className="px-4 py-3 flex items-center gap-3 border-b border-border/30">
          <div className="flex-1 h-1.5 rounded-full bg-surface overflow-hidden">
            <motion.div
              className="h-full rounded-full bg-gradient-to-r from-violet to-cyan"
              initial={{ width: 0 }}
              animate={{ width: `${Math.min((stats.total_turns / 50) * 100, 100)}%` }}
              transition={{ duration: 0.8, ease: "easeOut" }}
            />
          </div>
          <span className="text-[11px] text-dim whitespace-nowrap">
            {stats.total_turns}/50 turns
          </span>
          <button
            onClick={() => setShowPrompt(!showPrompt)}
            className="flex items-center gap-1 text-[11px] text-violet-light hover:text-violet transition-colors"
          >
            <Sparkles size={11} />
            View prompt
            <ChevronRight size={11} className={clsx("transition-transform", showPrompt && "rotate-90")} />
          </button>
        </div>
      )}

      {/* Personality prompt preview */}
      <AnimatePresence>
        {showPrompt && stats && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden border-b border-border/30"
          >
            <pre className="px-5 py-4 text-[11px] text-dim font-mono leading-relaxed max-h-[120px] overflow-y-auto whitespace-pre-wrap">
              {stats.personality_prompt}
            </pre>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Training turns history */}
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-3">
        {turns.length === 0 && (
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex flex-col items-center justify-center py-16 text-center"
          >
            <div className="w-16 h-16 rounded-2xl bg-violet/10 border border-violet/20 flex items-center justify-center mb-4">
              <Brain size={28} className="text-violet-light" strokeWidth={1.5} />
            </div>
            <p className="text-soft font-[600] text-[15px] mb-1">No training yet</p>
            <p className="text-dim text-[13px] max-w-[240px] leading-relaxed">
              Add example conversations below to teach your clone how you communicate.
            </p>
          </motion.div>
        )}

        {turns.map((turn, i) => (
          <motion.div
            key={turn.id ?? i}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.03 }}
            className="bg-card border border-border/60 rounded-2xl overflow-hidden"
          >
            <div className="px-4 py-3 border-b border-border/40">
              <span className="text-[10px] text-dim uppercase tracking-wider font-semibold">Someone asked</span>
              <p className="text-[13.5px] text-light mt-1 leading-relaxed">{turn.prompt}</p>
            </div>
            <div className="px-4 py-3 bg-violet/5">
              <span className="text-[10px] text-violet-light uppercase tracking-wider font-semibold">You replied</span>
              <p className="text-[13.5px] text-light mt-1 leading-relaxed">{turn.response}</p>
            </div>
          </motion.div>
        ))}
        <div ref={bottomRef} />
      </div>

      {/* Input panel */}
      <div className="flex-shrink-0 px-4 py-3 border-t border-border/50 glass space-y-2">
        <p className="text-[11px] text-dim font-[550] uppercase tracking-wider px-1">Add training example</p>
        <div className="bg-card border border-border rounded-2xl overflow-hidden">
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Someone's message to you…"
            rows={2}
            className="w-full px-4 pt-3 pb-1 bg-transparent text-[13.5px] text-light placeholder:text-muted resize-none focus:outline-none leading-relaxed"
          />
          <div className="h-px bg-border/50 mx-4" />
          <textarea
            value={response}
            onChange={(e) => setResponse(e.target.value)}
            placeholder="Your ideal reply…"
            rows={2}
            className="w-full px-4 pt-2 pb-3 bg-transparent text-[13.5px] text-light placeholder:text-muted resize-none focus:outline-none leading-relaxed"
          />
        </div>
        <motion.button
          onClick={handleSave}
          disabled={saving || !prompt.trim() || !response.trim()}
          whileTap={{ scale: 0.97 }}
          className={clsx(
            "w-full flex items-center justify-center gap-2 py-3 rounded-2xl",
            "text-[13.5px] font-[600] transition-all duration-150",
            prompt.trim() && response.trim()
              ? "bg-bubble-me text-white shadow-violet-glow/30 hover:opacity-90"
              : "bg-surface text-muted cursor-not-allowed"
          )}
        >
          {saving ? (
            <RefreshCw size={15} className="animate-spin" />
          ) : (
            <Send size={15} />
          )}
          Save training turn
        </motion.button>
      </div>
    </div>
  );
}
