"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import { Plus, Search, MessageCircle } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import clsx from "clsx";

import { useChatStore } from "@/store/chatStore";
import { api, type UserOut } from "@/lib/api";

export default function ChatsPage() {
  const { conversations, setConversations, currentUser, presence } = useChatStore();
  const [query, setQuery] = useState("");
  const [users, setUsers] = useState<UserOut[]>([]);
  const [showNewChat, setShowNewChat] = useState(false);
  const [creating, setCreating] = useState<string | null>(null);

  useEffect(() => {
    api.listConversations().then(setConversations).catch(() => {});
  }, []);

  const filteredConvs = conversations.filter((c) =>
    (c.name ?? "Chat").toLowerCase().includes(query.toLowerCase())
  );

  const startNewChat = async () => {
    setShowNewChat(true);
    const list = await api.listUsers().catch(() => []);
    setUsers(list.filter((u) => u.id !== currentUser?.id));
  };

  const openDirect = async (userId: string) => {
    if (creating) return;
    setCreating(userId);
    try {
      await api.createDirect(userId);
      const updated = await api.listConversations();
      setConversations(updated);
      setShowNewChat(false);
    } finally {
      setCreating(null);
    }
  };

  return (
    <div className="flex flex-col h-full bg-void">
      {/* Header */}
      <header className="flex items-center gap-3 px-5 py-4 border-b border-border/50">
        <h1 className="flex-1 text-[18px] font-[700] text-light tracking-tight">Messages</h1>
        <button
          onClick={startNewChat}
          className="w-9 h-9 rounded-full bg-bubble-me flex items-center justify-center shadow-violet-glow/40 hover:scale-105 transition-transform active:scale-95"
        >
          <Plus size={18} className="text-white" strokeWidth={2.5} />
        </button>
      </header>

      {/* Search */}
      <div className="px-4 py-3">
        <div className="flex items-center gap-2 bg-card border border-border rounded-2xl px-3 py-2.5">
          <Search size={15} className="text-muted flex-shrink-0" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search chats…"
            className="flex-1 bg-transparent text-[13.5px] text-light placeholder:text-muted focus:outline-none"
          />
        </div>
      </div>

      {/* New chat panel */}
      {showNewChat && (
        <div className="mx-4 mb-2 bg-card border border-violet/20 rounded-2xl overflow-hidden">
          <div className="px-4 py-2.5 border-b border-border/50 flex items-center justify-between">
            <span className="text-[12px] font-semibold text-violet-light uppercase tracking-wider">New chat</span>
            <button onClick={() => setShowNewChat(false)} className="text-dim hover:text-soft text-lg leading-none">×</button>
          </div>
          <div className="max-h-[180px] overflow-y-auto">
            {users.map((u) => (
              <button
                key={u.id}
                onClick={() => openDirect(u.id)}
                disabled={!!creating}
                className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-surface transition-colors text-left"
              >
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-violet-500 to-violet-800 flex items-center justify-center text-[12px] font-bold flex-shrink-0">
                  {u.username[0].toUpperCase()}
                </div>
                <span className="text-[13px] font-[500] text-light">{u.username}</span>
                {presence[u.id] && <span className="ml-auto w-2 h-2 rounded-full bg-cyan" />}
              </button>
            ))}
            {users.length === 0 && (
              <p className="text-center text-dim text-[13px] py-4">No other users yet</p>
            )}
          </div>
        </div>
      )}

      {/* Conversation list */}
      <div className="flex-1 overflow-y-auto px-3 space-y-1 pb-4">
        {filteredConvs.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex flex-col items-center justify-center py-20 text-center"
          >
            <MessageCircle size={40} className="text-muted mb-3" strokeWidth={1} />
            <p className="text-soft font-[550]">No chats yet</p>
            <p className="text-dim text-[13px] mt-1">Tap + to start one</p>
          </motion.div>
        )}
        {filteredConvs.map((conv, i) => (
          <motion.div
            key={conv.id}
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.05 }}
          >
            <Link
              href={`/chats/${conv.id}`}
              className="flex items-center gap-3 px-3 py-3 rounded-2xl hover:bg-surface transition-all duration-150 group"
            >
              <div className="relative flex-shrink-0">
                <div className={clsx(
                  "w-12 h-12 rounded-full flex items-center justify-center text-[15px] font-bold",
                  conv.type === "group"
                    ? "bg-gradient-to-br from-cyan/60 to-teal-700"
                    : "bg-gradient-to-br from-violet-500 to-violet-800"
                )}>
                  {(conv.name ?? "?")[0].toUpperCase()}
                </div>
                <span className={clsx(
                  "absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full border-2 border-void",
                  presence[conv.id] ? "bg-cyan" : "bg-muted"
                )} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-0.5">
                  <span className="text-[14px] font-[600] text-light truncate">
                    {conv.name ?? `Chat`}
                  </span>
                  <span className="text-[11px] text-dim flex-shrink-0 ml-2">
                    {formatDistanceToNow(new Date(conv.created_at), { addSuffix: true })}
                  </span>
                </div>
                <p className="text-[12.5px] text-dim truncate">
                  {conv.type === "group" ? "Group chat" : "Direct message"}
                </p>
              </div>
            </Link>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
