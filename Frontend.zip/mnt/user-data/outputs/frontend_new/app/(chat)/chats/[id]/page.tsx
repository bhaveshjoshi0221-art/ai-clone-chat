"use client";

import { useEffect, useRef, useCallback } from "react";
import { useParams } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import { Phone, Video, Info, ChevronLeft, Bot, Wifi, WifiOff } from "lucide-react";
import Link from "next/link";
import clsx from "clsx";

import { useChatStore } from "@/store/chatStore";
import { useWebSocket } from "@/hooks/useWebSocket";
import { api } from "@/lib/api";
import { chatSocket } from "@/lib/socket";
import { ChatBubble } from "@/components/ChatBubble";
import { MessageInput } from "@/components/MessageInput";
import { TypingIndicator } from "@/components/TypingIndicator";
import { CloneAvatar } from "@/components/CloneAvatar";

export default function ChatPage() {
  const { id } = useParams<{ id: string }>();
  const scrollRef = useRef<HTMLDivElement>(null);
  const loadingMore = useRef(false);

  const {
    messages: allMessages,
    setMessages,
    prependMessages,
    typing,
    currentUser,
    conversations,
  } = useChatStore();

  const messages = allMessages[id] ?? [];
  const typingInRoom = typing[id] ?? {};
  const typingUserIds = Object.entries(typingInRoom)
    .filter(([uid, t]) => t && uid !== currentUser?.id)
    .map(([uid]) => uid);

  const conversation = conversations.find((c) => c.id === id);

  // Activate WebSocket for this room
  useWebSocket(id);

  // Load message history
  useEffect(() => {
    if (!id) return;
    api.getMessages(id, 50).then((msgs) => setMessages(id, msgs)).catch(() => {});
  }, [id]);

  // Scroll to bottom on new messages
  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    const isNearBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 200;
    if (isNearBottom) el.scrollTo({ top: el.scrollHeight, behavior: "smooth" });
  }, [messages.length, typingUserIds.length]);

  // Infinite scroll — load older messages
  const handleScroll = useCallback(async () => {
    const el = scrollRef.current;
    if (!el || loadingMore.current) return;
    if (el.scrollTop > 80) return;
    const oldest = messages[0];
    if (!oldest) return;
    loadingMore.current = true;
    try {
      const older = await api.getMessages(id, 30, oldest.id);
      if (older.length > 0) prependMessages(id, older);
    } finally {
      loadingMore.current = false;
    }
  }, [id, messages]);

  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    el.addEventListener("scroll", handleScroll, { passive: true });
    return () => el.removeEventListener("scroll", handleScroll);
  }, [handleScroll]);

  // Send message
  const handleSend = (content: string) => {
    chatSocket.sendMessage(content);
  };

  // Mark seen on focus
  useEffect(() => {
    const last = messages[messages.length - 1];
    if (last && last.sender_user_id !== currentUser?.id) {
      chatSocket.sendSeen(last.id);
    }
  }, [messages.length]);

  const title = conversation?.name ?? "Chat";
  const isGroup = conversation?.type === "group";

  // Check if any clone is "active" (typing)
  const cloneTyping = typingUserIds.some((uid) => uid.startsWith("clone:"));

  return (
    <div className="flex flex-col h-full bg-void">
      {/* ── Header ─────────────────────────────────────────────────────── */}
      <header className="flex items-center gap-3 px-4 py-3 glass border-b border-border/50 flex-shrink-0">
        {/* Back (mobile) */}
        <Link href="/chats" className="md:hidden text-dim hover:text-soft">
          <ChevronLeft size={22} />
        </Link>

        {/* Avatar */}
        {isGroup ? (
          <div className="w-9 h-9 rounded-full bg-gradient-to-br from-cyan/60 to-teal-600 flex items-center justify-center text-[13px] font-bold">
            {title[0]?.toUpperCase()}
          </div>
        ) : (
          <CloneAvatar name={title} size="sm" active={cloneTyping} />
        )}

        {/* Title + status */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1.5">
            <h1 className="text-[15px] font-[650] text-light truncate">{title}</h1>
            {isGroup && (
              <span className="text-[10px] bg-cyan/15 text-cyan px-1.5 py-0.5 rounded-full font-semibold">
                Group
              </span>
            )}
          </div>
          <div className="flex items-center gap-1 mt-0.5">
            <AnimatePresence mode="wait">
              {chatSocket.connected ? (
                <motion.div key="on" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex items-center gap-1">
                  <Wifi size={10} className="text-cyan" />
                  <span className="text-[10px] text-cyan">Connected</span>
                </motion.div>
              ) : (
                <motion.div key="off" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex items-center gap-1">
                  <WifiOff size={10} className="text-dim" />
                  <span className="text-[10px] text-dim">Reconnecting…</span>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-1">
          <button className="w-9 h-9 rounded-full hover:bg-surface flex items-center justify-center text-dim hover:text-soft transition-colors">
            <Phone size={17} />
          </button>
          <button className="w-9 h-9 rounded-full hover:bg-surface flex items-center justify-center text-dim hover:text-soft transition-colors">
            <Video size={17} />
          </button>
          <button className="w-9 h-9 rounded-full hover:bg-surface flex items-center justify-center text-dim hover:text-soft transition-colors">
            <Info size={17} />
          </button>
        </div>
      </header>

      {/* ── Messages ───────────────────────────────────────────────────── */}
      <div
        ref={scrollRef}
        className="flex-1 overflow-y-auto chat-scroll py-4 space-y-0.5"
      >
        {/* Date separator (simplified) */}
        {messages.length > 0 && (
          <div className="flex items-center justify-center mb-2">
            <span className="text-[10px] text-dim bg-surface/80 px-3 py-1 rounded-full border border-border/50">
              Today
            </span>
          </div>
        )}

        {/* Empty state */}
        {messages.length === 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex flex-col items-center justify-center h-full text-center py-16 px-8"
          >
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-violet/20 to-cyan/10 border border-violet/20 flex items-center justify-center mb-4">
              <Bot size={28} className="text-violet-light" />
            </div>
            <p className="text-soft font-[550] text-[15px] mb-1">Start the conversation</p>
            <p className="text-dim text-[13px] leading-relaxed max-w-[240px]">
              Say hello! If your friend is offline, their AI clone will reply.
            </p>
          </motion.div>
        )}

        {/* Bubble list */}
        <AnimatePresence initial={false}>
          {messages.map((msg, i) => {
            const prevMsg = messages[i - 1];
            const showUsername =
              !prevMsg || prevMsg.sender_user_id !== msg.sender_user_id || prevMsg.sender_clone_id !== msg.sender_clone_id;

            return (
              <ChatBubble
                key={msg.id}
                message={msg}
                isMine={msg.sender_user_id === currentUser?.id}
                showUsername={showUsername}
                currentUserId={currentUser?.id}
              />
            );
          })}
        </AnimatePresence>

        {/* Typing indicators */}
        <AnimatePresence>
          {typingUserIds.map((uid) => (
            <TypingIndicator
              key={uid}
              username={uid.replace("clone:", "")}
              isClone={uid.startsWith("clone:")}
            />
          ))}
        </AnimatePresence>
      </div>

      {/* ── Input bar ──────────────────────────────────────────────────── */}
      <div className="flex-shrink-0 pb-safe">
        <MessageInput
          onSend={handleSend}
          placeholder={`Message ${title}…`}
        />
      </div>
    </div>
  );
}
